CREATE TABLE departments (
    depart_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    depart_name VARCHAR(100) NOT NULL,
    updated_at VARCHAR(50) NOT NULL
);
