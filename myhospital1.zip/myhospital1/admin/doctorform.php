<?php
session_start();
include_once 'include/config.php';

// Handle form submission
if (isset($_POST['submit'])) {
    $department = $_POST['department'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $pin_code = $_POST['pin_code'];
    $idtype = $_POST['idtype'];
    $idnum = $_POST['idnum'];
    
    // Handle password (hashing before saving)
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Prepare and bind the insert query
    $stmt = $conn->prepare("INSERT INTO doctors 
                            (department_id, name, email, mobile, gender, address, city, pin_code, id_type, id_number, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // Bind parameters
    $stmt->bind_param("issssssssss", $department, $name, $email, $mobile, $gender, $address, $city, $pin_code, $idtype, $idnum, $password);

    // Execute the query
    if ($stmt->execute()) {
        header("Location: managedoctors.php"); // Redirect after adding new doctor
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

include_once 'include/header.php';
?>

<div class="container">
    <h3 class="mt-4">Add New Doctor</h3>
    <form method="POST">
        <!-- Department field -->
        <div class="form-group">
            <label for="department">Department</label>
            <select name="department" id="department" class="form-control" required>
                <?php
                    // Fetch departments from the 'departments' table
                    $sql = "SELECT * FROM departments";
                    $run = mysqli_query($conn, $sql);
                    while ($depart = mysqli_fetch_assoc($run)) {
                        echo "<option value='{$depart['depart_id']}'>{$depart['depart_name']}</option>";
                    }
                ?>
            </select>
        </div>

        <!-- Other fields (name, email, etc.) -->
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="mobile">Mobile</label>
            <input type="text" name="mobile" id="mobile" class="form-control" required>
        </div>

        <!-- Gender Dropdown -->
        <div class="form-group">
            <label for="gender">Gender</label>
            <select name="gender" id="gender" class="form-control" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>

        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" id="address" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" name="city" id="city" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="pin_code">Pin Code</label>
            <input type="text" name="pin_code" id="pin_code" class="form-control" required>
        </div>

        <!-- ID Type Dropdown -->
        <div class="form-group">
            <label for="idtype">ID Type</label>
            <select name="idtype" id="idtype" class="form-control" required>
                <option value="National Identity Card">National Identity Card</option>
                <option value="Pan Card">Pan Card</option>
            </select>
        </div>

        <div class="form-group">
            <label for="idnum">ID Number</label>
            <input type="text" name="idnum" id="idnum" class="form-control" required>
        </div>

        <!-- Password field -->
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>

        <!-- Submit button -->
        <button type="submit" name="submit" class="btn btn-success">Add Doctor</button>
    </form>
</div>

<?php
include_once 'include/footer.php';
?>
