    <footer class="pt-4 my-md-5 pt-md-5 border-top shadow-none">
        <div class="row">
          <div class="col-12 col-md shadow-lg p-3 m-2">
            <h1>CareFirst Hospital </h1>
            <small class="d-block mb-3 text-muted">Best healthcare service</small>
          </div>
          <div class="col-6 col-md shadow-lg p-3 m-2 ">
            <h5>Features</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Book Appoinment</a></li>
              <li><a class="text-muted" href="#">Online Consult</a></li>
              <li><a class="text-muted" href="#">Provides quality of services</a></li>
            </ul>
          </div>
          <div class="col-6 col-md shadow-lg p-3 m-2">
            <h5>Resources</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Hospital Galary</a></li>
              
            </ul>
          </div>
          <div class="col-6 col-md shadow-lg p-3 m-2">
            <h5>Contact</h5>
            <ul class="list-unstyled text-small text-primary">
              <li>CareFirst Hospital</li>
              <li>Gongabu, Ring Road</li>
              <li>Kathmandu 44611</li>
              <li>Mo - 478569</li>
              <li>Email - carefirsthospital@gmail.com</li>
            </ul>
          </div>
        </div>
      </footer>
</div> 
</body>
</html>